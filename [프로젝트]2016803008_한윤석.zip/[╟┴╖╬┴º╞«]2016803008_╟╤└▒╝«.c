#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <termio.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/procfs.h>
#include <errno.h>
#include <sys/wait.h>

#define MAX_LINE 1024
#define MAX_FILE_NAME_SIZE 4096

#define COMMAND_LS 1
#define COMMAND_RM 2
#define COMMAND_CAT 3
#define COMMAND_GREP 4
#define COMMAND_PS 5

char commandLine[MAX_LINE] = {0, };
int inputPointer = 0;

void execute_to_shell(char command[]) {
  if (!command) {
    return;
  }

  int pid = 0;

  pid = fork();

  if (pid == 0) {
    execlp("/bin/sh", "/bin/sh", "-c", command, NULL);
    _exit(1);
  }

  int status = 0;
  int r = wait(&status);
}

int improve_getch() {
  int ch;
  struct termios buf, save;
  tcgetattr(0, &save);
  buf = save;
  buf.c_lflag &= ~(ICANON | ECHO | ISIG);
  buf.c_cc[VMIN] = 1;
  buf.c_cc[VTIME] = 0;
  tcsetattr(0, TCSAFLUSH, &buf);
  ch = getchar();
  tcsetattr(0, TCSAFLUSH, &save);
  return ch;
}

void quit_handler(int sig_num) {
  printf("%c", commandLine[inputPointer]);
}

int main(int argc, char *argv[]) {
  int backspaced = 0;
  int tapped = 0;
  int double_tapped = 0;
  int all_blank = 0;

  signal(SIGINT, quit_handler);
  signal(SIGQUIT, quit_handler);

  while(1) {
    printf("User Shell >> ");

    if (backspaced == 1) {
      printf("%s", commandLine);
      backspaced = 0;
    }

    if (tapped > 0) {
      printf("%s", commandLine);
      tapped = 0;
      double_tapped = 1;
    }

    while((commandLine[inputPointer] = improve_getch()) != '\n') {
      if (commandLine[inputPointer] != 9) {
        double_tapped = 0;
        tapped = 0;
      }

      if (commandLine[inputPointer] == 127) {
        system("clear");
        backspaced = 1;
        if (inputPointer == 0) {
          inputPointer = 1;
        }
        commandLine[inputPointer-1] = 0;
        inputPointer -= 1;
        break;
      } else if (commandLine[inputPointer] == 9) {
        commandLine[inputPointer] = ' ';

        tapped = 1;

        if (double_tapped == 1) {
          printf("\n");
          execute_to_shell("ls");
          double_tapped = 0;
          tapped = 0;
        } else {
          all_blank = 0;

          for(int i = 0; i < inputPointer; i++) {
            if (commandLine[i] != ' ') {
              all_blank = 1;
            }
          }

          if (all_blank == 0) {
            if (tapped) {
              double_tapped = 1;
            }
            continue;
          }

            DIR *dir = opendir(".");
            int blankSpaceIndex = 0;
            commandLine[inputPointer] = 0;
            for(int i = inputPointer; i > 0; i--) {
              if (commandLine[i] == ' ') {
                blankSpaceIndex = i;
                break;
              }
            }

            if (blankSpaceIndex != 0) {
              blankSpaceIndex += 1;
            }

            char *startPointer = (commandLine+blankSpaceIndex);
            if (dir) {
              struct dirent *file = NULL;
              struct stat fileStat;
              memset(&fileStat, 0, sizeof(struct stat));
              int j = -1;
              int i = -1;
              char fileBuf[MAX_FILE_NAME_SIZE] = {0, };
              while((file = readdir(dir)) != NULL) {
                snprintf(fileBuf, MAX_FILE_NAME_SIZE, "%s/%s", ".", file->d_name);
                startPointer = (commandLine+blankSpaceIndex);
                if (stat(fileBuf, &fileStat) >= 0) {
                  char *ptr = strstr(file->d_name, startPointer);
                  //printf("comp [%s] [%s]\n", file->d_name, startPointer);
                  if(ptr != NULL) {
                    int length = strlen(file->d_name);
                    j = 0;
                    for(i = blankSpaceIndex; i < blankSpaceIndex+length; i++, j++) {
                      if (commandLine[i] != file->d_name[j]) {
                        inputPointer += 1;
                      }

                      commandLine[i] = file->d_name[j];
                    }
                    break;
                  }
                }
                memset(fileBuf, 0, MAX_FILE_NAME_SIZE);
              }
              closedir(dir);
              if (i >= 0 || j >= 0) {
                break;
              }
            }
          }
      } else {
        tapped = 0;
        double_tapped = 0;
      }

      printf("%c", commandLine[inputPointer]);

      if (inputPointer >= MAX_LINE) {
        printf("\nMax limit\n");
        break;
      }
      inputPointer += 1;
    }

    printf("\n");

    if (tapped || backspaced) {
      continue;
    }
    if (commandLine[inputPointer] == '\n') {
      commandLine[inputPointer] = 0;
      double_tapped = 0;
      tapped = 0;
    }

    if (backspaced == 0 || tapped == 0) {
      if (strcmp("q", commandLine) == 0) {
        exit(0);
      }
      execute_to_shell(commandLine);
      memset(commandLine, 0, MAX_LINE);
      inputPointer = 0;
    }

  }

  return 0;

}
