#!/bin/bash

num_files=0
position=0
position_start=0
position_end=25
position_next=0
copy_count=0
move_count=0

function init_program()
{
	clean_file_list
	num_files=0
	position=0
	position_start=0
	position_end=25
	position_next=0
}


function paste_copy()
{
	if [ $copy_count -gt 0 ];
	then
		for (( i=0 ; i < $copy_count; i++));
		do
			cp "${copy_array[$i]}" `pwd`/ -rf
			copy_array[$i]=""
		done
	fi
	update_current_directory
	show_current_directory
	print_info
	copy_count=0
}		

function paste_move()
{
	if [ $move_count -gt 0 ];
	then
		for (( i=0 ; i < $move_count; i++));
		do
			mv "${move_array[$i]}" `pwd`/
			move_array[$i]=""
		done
	fi
	update_current_directory
	show_current_directory
	print_info
	move_count=0
}		


function clean_file_list()
{
	for (( i=0 ; i <= $num_files; i++));
	do
		filename_array[$i]=""
	done
}

function print_info()
{
	local f=${filename_array[$position]}
	tput cup 28 0
	echo "|                                                                                  |"
	echo "|                                                                                  |"
	echo "|                                                                                  |"
	echo "|                                                                                  |"
	echo "|                                                                                  |"
	echo "|                                                                                  |"
	echo "|                                                                                  |"

	tput cup 28 22
	echo "file name : $f"
	tput cup 29 22
	echo "file type : "`stat -c %F $f`
	tput cup 30 22
	echo "file size : "`stat -c %s $f`
	tput cup 31 22
	echo "last modification type : "`stat -c %y $f`
	tput cup 32 22
	echo "permission : "`stat -c %a $f`
	tput cup 33 22
	echo "absolute path : "`pwd`"/$f"
}

function get_key()
{
	read -r -sn1 input
	
	case "$input" in
	A) position_next=`expr $position - 5`
	   if [ $position_next -lt 0 ];
	   then
		   position_next=0
	   fi;;
	B) position_next=`expr $position + 5`
	   if [ $position_next -gt $num_files ];
	   then
		   position_next=$num_files
	   fi;;
	C) position_next=`expr $position + 1`
	   if [ $position_next -gt $num_files ];
	   then
		   position_next=$num_files
	   fi;;

	D) position_next=`expr $position - 1`
	   if [ $position_next -lt 0 ];
	   then
		   position_next=0
	   fi;;
	"") enter_file;;
	'c') copy_file;;
	'p') paste_copy;;
	'm') move_file;;
	'v') paste_move;;
	esac
}

function copy_file()
{

	if [ $copy_count -le 3 ];
	then
		copy_array[$copy_count]="`pwd`"/${filename_array[$position]}
		copy_count=`expr $copy_count + 1`
		tput cup 39 1
		echo ${copy_array[@]}
	fi
}

function move_file()
{

	if [ $move_count -le 3 ];
	then
		move_array[$move_count]="`pwd`"/${filename_array[$position]}
		move_count=`expr $move_count + 1`
		tput cup 42 1
		echo ${move_array[@]}
	fi
}

function paste()
{
	echo paste
}
function enter_file()
{
	local f=${filename_array[$position]}
	local permission=`stat -c %A $f`	
	if [ "`stat -c %F $f`" = "디렉토리" ];
	then
		cd $f
		draw_frame
		init_program
		show_upper_directory
		update_current_directory
		show_current_directory
		print_info
	elif [[ "$permission" =~ .*x.* ]];
	then
		./$f
		clear
		draw_frame
		show_upper_directory
		show_current_directory
		print_info
	fi
}

function echo_text_with_color()
{
	echo -e "\033[$2m $1"
}

function update_current_directory()
{
	local i=1
	local num_dir=0
	local num_normal=0
	local num_special=0
	local total_size=0

	filename_array[0]=".."
	for filename in `ls | sort` ; 
	do
		if [ "`stat -c %F $filename`" = "디렉토리" ];
		then
			local size=`stat -c %s $filename`
			filename_array[$i]=$filename
			i=`expr $i + 1`
			num_dir=`expr $num_dir + 1`
			total_size=`expr $total_size + $size`
		fi
	done

	for filename in `ls | sort` ;
	do
		if  [ "`stat -c %F $filename | cut -c 1-3`" != "디" ] && \
		    [ -x $filename ];
		then
			local size=`stat -c %s $filename`
			filename_array[$i]=$filename
			i=`expr $i + 1`
			num_special=`expr $num_special + 1`
			total_size=`expr $total_size + $size`
		fi
	done

	for filename in `ls | sort` ; 
	do
		if [ "`stat -c %F $filename | cut -c 1-6`" = "일반" ] && \
		   ! [ -x $filename ]; 
		then
			local size=`stat -c %s $filename`
			filename_array[$i]=$filename
			i=`expr $i + 1`
			num_normal=`expr $num_normal + 1`
			total_size=`expr $total_size + $size`
		fi
	done
	
	num_files=`expr $i - 1`

	echo -e "\033[0;0m"
	tput cup 36 22
	echo $num_files "total" $num_dir "dir" $num_normal "file" $num_special "Sfile" $total_size "byte"

#echo ${filename_array[@]} $num_files
}
function show_current_directory()
{
	for (( i= $position_start ; i < $position_end; i++));
	do
		draw_file $i
	done
}

function show_upper_directory()
{
	local x=1
	local y=1

	for (( i= 0 ; i < 26; i++));
	do
		tput cup `expr $x + $i` $y
		echo "                   "
	done
	for filename in `ls ../ | sort` ;
	do
		local f=`echo "$filename" | cut -c 1-18`
		if [ $x -gt 20 ]
		then
			return
		fi
 		if [ "`stat -c %F ../$filename`" = "디렉토리" ];
		then
			tput cup $x $y
			echo_text_with_color $f 34
			x=`expr $x + 1`
		fi
	done
	
	for filename in `ls ../ | sort` ;
	do
		local f=`echo "$filename" | cut -c 1-18`
		if [ $x -gt 20 ]
		then
			return
		fi
		if [ "`stat -c %F ../$filename | cut -c 1-3`" != "디" ] && \
		   [ -x ../$filename ];
		then
			tput cup $x $y
			echo_text_with_color $f 31
			x=`expr $x + 1`
		fi
	done

	for filename in `ls ../ | sort` ;
	do
		local f=`echo "$filename" | cut -c 1-18`
		if [ $x -gt 20 ]
		then
			return
		fi
		if [ "`stat -c %F ../$filename | cut -c 1-6`" = "일반" ] && \
		   ! [ -x ../$filename ];
		then
			tput cup $x $y
			echo_text_with_color $f 0
			x=`expr $x + 1`
		fi
	done

}

function draw_directory()
{
	local x=$1
	local y=$2
	local filename=`echo "$3" | cut -c 1-10`
	local def_color=34

	if [ "$3" = ".." ] ;
	then
		def_color=31
	fi

	tput cup $x $y
	echo_text_with_color "     __" $def_color
	x=`expr $x + 1`
	tput cup $x $y
	echo_text_with_color "/---/ |" $def_color
	x=`expr $x + 1`
	tput cup $x $y
	echo_text_with_color "|  d  |" $def_color
	x=`expr $x + 1`
	tput cup $x $y
	echo_text_with_color "-------" $def_color
	x=`expr $x + 1`
	tput cup $x $y
	echo "           "
	tput cup $x $y
	echo_text_with_color $filename $def_color
	echo -e "\033[0;0m"
}

function draw_normal()
{
	local x=$1
	local y=$2
	local filename=`echo "$3" | cut -c 1-10`
	
	tput cup $x $y
	echo_text_with_color "_______" 37
	x=`expr $x + 1`
	tput cup $x $y
	echo_text_with_color "|     |" 37
	x=`expr $x + 1`
	tput cup $x $y
	echo_text_with_color "|  o  |" 37
	x=`expr $x + 1`
	tput cup $x $y
	echo_text_with_color "-------" 37
	x=`expr $x + 1`
	tput cup $x $y
	echo "           "
	tput cup $x $y
	echo_text_with_color $filename 37
	echo -e "\033[0;0m"
}

function draw_special()
{
	local x=$1
	local y=$2
	local filename=`echo "$3" | cut -c 1-10`

	tput cup $x $y
	echo_text_with_color "_______" 31
	x=`expr $x + 1`
	tput cup $x $y
	echo_text_with_color "|     |" 31
	x=`expr $x + 1`
	tput cup $x $y
	echo_text_with_color "|  x  |" 31
	x=`expr $x + 1`
	tput cup $x $y
	echo_text_with_color "-------" 31
	x=`expr $x + 1`
	tput cup $x $y
	echo "           "
	tput cup $x $y
	echo_text_with_color $filename 31
	echo -e "\033[0;0m"
}

function draw_none()
{
	local x=$1
	local y=$2

	tput cup $x $y
	echo "           "	
	x=`expr $x + 1`
	tput cup $x $y
	echo "           "
	x=`expr $x + 1`
	tput cup $x $y
	echo "           "
	x=`expr $x + 1`
	tput cup $x $y
	echo "           "
	x=`expr $x + 1`
	tput cup $x $y
	echo "           "
}

function draw_file()
{
	local x=1
	local y=24
	local f=${filename_array[$1]}
	if [ $1 -eq $position ];
	then
		echo -e "\033[;42m"
	fi
	x=`expr $x + \( \( $1 - $position_start \) / 5 \) \* 5`
	y=`expr $y + \( \( $1 - $position_start \) % 5 \) \* 12`
	
	if [ "$f" = "" ];
	then
		draw_none $x $y
	elif [ "`stat -c %F $f`" = "디렉토리" ];
	then
		draw_directory $x $y $f
	elif [ "`stat -c %F $f | cut -c 1-3`" != "디" ] && \
		 [ -x $f ]
	then
		draw_special $x $y $f
	elif [ "`stat -c %F $f | cut -c 1-6`" = "일반" ];
	then
		draw_normal $x $y $f
	fi
	
	if [ $1 -eq $position ];
	then
		echo -e "\033[;0m"
	fi
}

function draw_frame()
{
clear
	echo "===================================================================================="
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|                    |                                                             |"
	echo "|********************************** Information ***********************************|"
	echo "|                                                                                  |"
	echo "|                                                                                  |"
	echo "|                                                                                  |"
	echo "|                                                                                  |"
	echo "|                                                                                  |"
	echo "|                                                                                  |"
	echo "|                                                                                  |"
	echo "|********************************** Information ***********************************|"
	echo "|                                                                                  |"
	echo "===================================================================================="
	echo "< List to copy > (press 'c' to select files to copy)"
	echo "                                                                                    "
	echo "                                                                                    "
	echo "< List to move > (press 'm' to select files to move)"
}

clear
draw_frame
show_upper_directory
update_current_directory
show_current_directory
print_info
while(true)
do
	get_key
	if [ $position_next -ge $position_end ];
	then
		position_start=`expr $position_start + 5`
		position_end=`expr $position_end + 5`
		show_current_directory
	elif [ $position_next -lt $position_start ];
	then
		position_start=`expr $position_start - 5`
		position_end=`expr $position_end - 5`
		show_current_directory
	fi
	if [ $position_next -ne $position ];
	then
		position_prev=$position
		position=$position_next
		
		draw_file $position_prev
		draw_file $position_next
		print_info
	fi
done
